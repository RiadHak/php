<h1>php is less cool</h1>
<img src="images/php.jpg" class="content_image" alt="">
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut voluptas, quaerat voluptatum beatae consectetur quis voluptates. Error sapiente provident commodi nesciunt, porro quis. Exercitationem voluptatem rerum hic aliquid mollitia atque?</p>
<!-- jouw HTML met de inhoud over onderwerp 1 komt hier... -->