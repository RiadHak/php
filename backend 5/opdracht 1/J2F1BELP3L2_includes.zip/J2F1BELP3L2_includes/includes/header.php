<!-- jouw HTML voor een Header komt hier... 
Gebruik hier tenminste een header afbeelding en een menu
Zorg dat je in het menu bij elk item een url parameter zet
om te bepalen welke inhoud er ingeladen moet worden in je html
-->
<ul>
  <li><a href="index.php?name=lol" name="lol" >League Of Legends</a></li>
  <li><a href="index.php?name=valo" name="Valorant">Valorant</a></li>
  <li><a href="index.php?name=ph" name="ph">Php</a></li>
  <li><a href="index.php?name=py" name="pyhton">Python</a></li>
  <img src="images/php.jpg" alt="PHP">
</ul>



