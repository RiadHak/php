<?php 
$name = 'Riad';
$achternaam = 'Alhakim';
?>