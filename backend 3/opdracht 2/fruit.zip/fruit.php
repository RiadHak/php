<?php 
$fruits = ['appel','banan','ananas' ];

?>